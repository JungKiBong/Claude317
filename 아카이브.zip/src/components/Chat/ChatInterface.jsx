import React, { useState, useEffect, useRef } from 'react';
import { Send, X, Plus, Upload, Image, File, Link, Sparkles, Zap, Copy, ThumbsUp, ThumbsDown, Share } from 'lucide-react';

const ChatInterface = ({ onClose }) => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      role: 'assistant',
      content: '안녕하세요! BADA AI 어시스턴트입니다. 배터리 데이터 분석에 관한 질문이나 도움이 필요한 것이 있으신가요?',
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSendMessage = () => {
    if (input.trim() === '') return;
    
    // Add user message
    const userMessage = {
      id: messages.length + 1,
      role: 'user',
      content: input,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    // Simulate AI response after delay
    setTimeout(() => {
      const responses = [
        '배터리 데이터 분석을 위한 최적의 방법은 시계열 분석과 이상 감지 알고리즘을 결합하는 것입니다. BADA 플랫폼에서는 Pipeline Canvas를 통해 이러한 분석 파이프라인을 쉽게 구축할 수 있습니다.',
        '배터리 수명 예측 모델을 개발하려면 충방전 사이클 데이터와 온도 데이터를 함께 고려해야 합니다. 저희 플랫폼의 DataSets 메뉴에서 샘플 데이터셋을 확인해 보세요.',
        '배터리 성능 저하의 주요 요인은 온도, 충전 속도, 사용 패턴 등이 있습니다. 이러한 요소들을 종합적으로 분석하는 리포트 템플릿을 Report 메뉴에서 찾아보실 수 있습니다.',
        '전기차 배터리 데이터를 분석하려면 먼저 BMS(배터리 관리 시스템) 데이터를 전처리해야 합니다. 우리 플랫폼의 DevCode에서 데이터 전처리 코드 샘플을 확인해 보세요.'
      ];
      
      const aiMessage = {
        id: messages.length + 2,
        role: 'assistant',
        content: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date(),
        sources: [
          { title: '배터리 성능 분석 보고서', type: 'report', date: '2024-02-15' },
          { title: '배터리 수명 예측 모델', type: 'model', date: '2024-01-20' }
        ]
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1500);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Format timestamp to show only time
  const formatTime = (date) => {
    return new Date(date).toLocaleTimeString('ko-KR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900">
      {/* Chat header */}
      <div className="border-b border-gray-200 dark:border-gray-800 p-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
            <Sparkles size={18} className="text-white" />
          </div>
          <div className="ml-3">
            <h2 className="font-medium text-gray-900 dark:text-white">BADA AI</h2>
            <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
              <Zap size={12} className="mr-1" />
              <span>배터리 전문 AI 어시스턴트</span>
            </div>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400"
        >
          <X size={20} />
        </button>
      </div>
      
      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((message) => (
          <div 
            key={message.id} 
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-3xl rounded-lg p-4 ${
                message.role === 'user' 
                  ? 'bg-blue-500 text-white ml-12'
                  : 'bg-gray-100 dark:bg-gray-800 dark:text-white mr-12'
              }`}
            >
              <div className="prose dark:prose-invert">
                {message.content}
              </div>
              
              {/* Sources section for AI responses */}
              {message.role === 'assistant' && message.sources && (
                <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">소스:</div>
                  <div className="space-y-1">
                    {message.sources.map((source, idx) => (
                      <div 
                        key={idx}
                        className="flex items-center text-xs text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                      >
                        {source.type === 'report' ? <File size={12} className="mr-1" /> : <Image size={12} className="mr-1" />}
                        <span>{source.title} ({source.date})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Timestamp */}
              <div 
                className={`text-xs mt-1 ${
                  message.role === 'user' ? 'text-blue-200' : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                {formatTime(message.timestamp)}
              </div>
            </div>
          </div>
        ))}
        
        {/* Loading indicator */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 max-w-3xl mr-12">
              <div className="flex space-x-2">
                <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        {/* Dummy div for scrolling to bottom */}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Last message actions - for the last AI message */}
      {messages.length > 1 && messages[messages.length - 1].role === 'assistant' && !isLoading && (
        <div className="px-4 py-2 flex space-x-2">
          <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400" title="복사">
            <Copy size={16} />
          </button>
          <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400" title="좋아요">
            <ThumbsUp size={16} />
          </button>
          <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400" title="싫어요">
            <ThumbsDown size={16} />
          </button>
          <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400" title="공유">
            <Share size={16} />
          </button>
        </div>
      )}
      
      {/* Input area */}
      <div className="border-t border-gray-200 dark:border-gray-800 p-4">
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg">
          <div className="flex p-1">
            <button className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400" title="새 채팅">
              <Plus size={16} />
            </button>
            <button className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400" title="파일 업로드">
              <Upload size={16} />
            </button>
            <button className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400" title="이미지 업로드">
              <Image size={16} />
            </button>
            <button className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400" title="링크 첨부">
              <Link size={16} />
            </button>
          </div>
          
          <div className="px-3 pb-3">
            <div className="flex items-center bg-white dark:bg-gray-700 rounded-lg border border-gray-300 dark:border-gray-600">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 p-2 bg-transparent outline-none resize-none max-h-32 text-gray-900 dark:text-white"
                placeholder="배터리 데이터 분석에 대해 질문하세요..."
                rows={1}
              />
              <button
                onClick={handleSendMessage}
                disabled={input.trim() === '' || isLoading}
                className={`p-2 rounded-full mx-2 ${
                  input.trim() === '' || isLoading
                    ? 'text-gray-400 dark:text-gray-600'
                    : 'text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900'
                }`}
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
        
        <div className="text-xs text-center mt-2 text-gray-500 dark:text-gray-400">
          BADA AI는 배터리 데이터 분석 및 해석에 특화된 AI 어시스턴트입니다. © 2025 BADA
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
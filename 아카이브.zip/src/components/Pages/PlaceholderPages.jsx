import React, { useState } from 'react';
import { 
  Layers, 
  FileText, 
  LayoutGrid, 
  Code, 
  Share2, 
  Upload, 
  BookOpen, 
  MessageCircle, 
  Settings,
  ExternalLink
} from 'lucide-react';
 
// Placeholder component for pages that would be fully implemented later
const PlaceholderPage = ({ title, description, icon, linkText, linkUrl }) => {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <div className="flex justify-center mb-4">
          <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
            {icon}
          </div>
        </div>
        <h2 className="text-xl font-semibold mb-4 dark:text-white">{title}</h2>
        <p className="mb-6 text-gray-600 dark:text-gray-300">{description}</p>
        
        {linkUrl && (
          <a 
            href={linkUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {linkText || '자세히 보기'}
            <ExternalLink size={16} className="ml-2" />
          </a>
        )}
      </div>
    </div>
  );
};

// Individual page components using the placeholder
//export const PipelineCanvas = () => (
//  <PlaceholderPage
//    title="Pipeline Canvas"
//    description="데이터셋 정의 및 저장을 위한 캔버스 환경입니다. 드래그 앤 드롭 방식으로 데이터 파이프라인을 구성하고 처리 과정을 시각화할 수 있습니다."
//    icon={<Layers size={24} />}
//    linkText="캔버스 시작하기"
//    linkUrl="http://google.com"
//  />
//);
export const PipelineCanvas = () => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <div className="w-full h-full flex flex-col">
      {/* 기존 헤더 코드 */}
      <div className="flex-grow relative">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/50 dark:bg-gray-900/50">
            <div className="spinner">로딩 중...</div>
          </div>
        )}
        <iframe 
          src="http://daum.net" 
          className="w-full h-full border-none"
          title="Pipeline Canvas"
          onLoad={() => setIsLoading(false)}
        />
      </div>
      {/* 기존 설명 텍스트 */}
    </div>
  );
};

export const Reports = () => (
  <PlaceholderPage
    title="Reports"
    description="배터리 분석 관련 내부 및 외부 리포트를 검색하고 공유할 수 있는 페이지입니다. 팀별, 카테고리별로 리포트를 관리하고 사용할 수 있습니다."
    icon={<FileText size={24} />}
  />
);

export const Apps = () => (
  <PlaceholderPage
    title="Apps"
    description="배터리 데이터 분석을 위한 웹 애플리케이션 모음입니다. 내부 개발 앱과 외부 연동 앱을 이용할 수 있습니다."
    icon={<LayoutGrid size={24} />}
  />
);

export const DevCode = () => (
  <PlaceholderPage
    title="DevCode"
    description="주피터 노트북 환경에서 코드를 작성하고 공유할 수 있는 페이지입니다. 데이터 분석 코드를 팀원들과 함께 작업하고 결과를 확인할 수 있습니다."
    icon={<Code size={24} />}
    linkText="코드 편집기 열기"
  />
);

export const DevApp = () => (
  <PlaceholderPage
    title="DevApp"
    description="Superset 및 AppSmith와 연계한 개발 환경입니다. 데이터 시각화 및 대시보드 구성, 간단한 앱 개발을 지원합니다."
    icon={<Share2 size={24} />}
  />
);

export const PubApp = () => (
  <PlaceholderPage
    title="PubApp"
    description="개발한 리포트와 앱을 배포하는 페이지입니다. CI/CD 파이프라인과 MLOps 워크플로우를 통해 안정적인 배포를 지원합니다."
    icon={<Upload size={24} />}
  />
);

export const Board = () => (
  <PlaceholderPage
    title="Board"
    description="공지사항, 지식 공유, 커뮤니티 게시판, 사용자 가이드, 팀 소개 등 다양한 정보를 확인할 수 있는 페이지입니다."
    icon={<BookOpen size={24} />}
  />
);

export const VOC = () => (
  <PlaceholderPage
    title="VOC 등록"
    description="요청 사항을 접수하고 처리 현황을 확인할 수 있는 페이지입니다. 시스템 개선 요청, 오류 보고, 기능 제안 등을 등록할 수 있습니다."
    icon={<MessageCircle size={24} />}
  />
);

export const SettingsPage = () => (
  <PlaceholderPage
    title="설정"
    description="시스템 설정 페이지입니다. 계정 관리, 알림 설정, 테마 변경, 권한 관리 등 다양한 설정을 변경할 수 있습니다."
    icon={<Settings size={24} />}
  />
);
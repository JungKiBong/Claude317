import React, { useState } from 'react';
import { Search, Filter, Star, Download, Clock, FileText, Users, ChevronUp, ChevronDown, Tag, Grid, List, Database, ArrowUp, ArrowDown, ExternalLink, Share } from 'lucide-react';

const Datasets = () => {
  const [viewMode, setViewMode] = useState('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [expandedFilter, setExpandedFilter] = useState('');
  
  // Sample datasets
  const datasets = [
    {
      id: 'ds1',
      title: '리튬이온 배터리 열화 데이터셋',
      description: '다양한 조건에서 사이클링된 리튬이온 배터리의 열화 패턴 데이터',
      tags: ['리튬이온', '배터리', '열화', '사이클링'],
      type: '테이블형',
      size: '4.3GB',
      rows: '2.1M',
      created: '2025-02-15',
      owner: '김연구원',
      downloads: 342,
      favorites: 56,
      isPublic: true,
      isVerified: true
    },
    {
      id: 'ds2',
      title: '전기차 배터리 BMS 데이터',
      description: '전기차 주행 중 기록된 배터리 관리 시스템(BMS) 데이터 모음',
      tags: ['전기차', 'BMS', '주행', '배터리'],
      type: '시계열',
      size: '8.7GB',
      rows: '5.6M',
      created: '2025-01-28',
      owner: '이분석가',
      downloads: 289,
      favorites: 42,
      isPublic: true,
      isVerified: true
    },
    {
      id: 'ds3',
      title: '배터리 셀 제조 공정 데이터',
      description: '리튬 배터리 셀 제조 과정에서 수집된 공정 및 품질 데이터',
      tags: ['제조', '공정', '품질', '셀'],
      type: '혼합형',
      size: '6.1GB',
      rows: '3.7M',
      created: '2025-03-02',
      owner: '박품질',
      downloads: 156,
      favorites: 28,
      isPublic: false,
      isVerified: true
    },
    {
      id: 'ds4',
      title: '전해질 성분 분석 데이터',
      description: '다양한 배터리 전해질 성분 분석 결과 및 성능 지표',
      tags: ['전해질', '성분', '분석', '성능'],
      type: '테이블형',
      size: '2.8GB',
      rows: '950K',
      created: '2025-02-08',
      owner: '최소재',
      downloads: 201,
      favorites: 34,
      isPublic: true,
      isVerified: false
    },
    {
      id: 'ds5',
      title: '배터리 안전성 테스트 데이터',
      description: '다양한 환경 조건에서의 배터리 안전성 테스트 결과',
      tags: ['안전성', '테스트', '환경', '위험'],
      type: '시계열',
      size: '3.5GB',
      rows: '1.8M',
      created: '2025-01-10',
      owner: '정안전',
      downloads: 267,
      favorites: 48,
      isPublic: true,
      isVerified: true
    },
    {
      id: 'ds6',
      title: '고체 전해질 배터리 성능 데이터',
      description: '차세대 고체 전해질 배터리의 성능 측정 데이터',
      tags: ['고체', '전해질', '차세대', '성능'],
      type: '테이블형',
      size: '1.9GB',
      rows: '780K',
      created: '2025-03-05',
      owner: '강미래',
      downloads: 98,
      favorites: 23,
      isPublic: false,
      isVerified: false
    }
  ];
  
  // Filter options
  const filterOptions = {
    tags: ['리튬이온', '전기차', 'BMS', '열화', '사이클링', '제조', '공정', '전해질', '고체', '안전성', '성능', '셀'],
    types: ['테이블형', '시계열', '혼합형'],
    availability: ['공개', '비공개'],
    verification: ['검증됨', '검증되지 않음']
  };
  
  // Toggle filter expansion
  const toggleFilter = (filter) => {
    setExpandedFilter(expandedFilter === filter ? '' : filter);
  };
  
  // Filter datasets based on search query
  const filteredDatasets = datasets.filter(dataset => 
    dataset.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dataset.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dataset.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  // Sort datasets
  const sortedDatasets = [...filteredDatasets].sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.created) - new Date(a.created);
      case 'oldest':
        return new Date(a.created) - new Date(b.created);
      case 'downloads':
        return b.downloads - a.downloads;
      case 'favorites':
        return b.favorites - a.favorites;
      default:
        return 0;
    }
  });
  
  // Card view for datasets
  const renderDatasetCards = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sortedDatasets.map(dataset => (
        <div 
          key={dataset.id}
          className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden hover:shadow-md transition-shadow"
        >
          <div className="p-6">
            <div className="flex justify-between items-start">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-md text-blue-600 dark:text-blue-300">
                  <Database size={20} />
                </div>
                <div className="ml-2 flex flex-col">
                  <h3 className="font-medium text-gray-900 dark:text-white">{dataset.title}</h3>
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    <span>{dataset.owner}</span>
                    <span className="mx-1">•</span>
                    <Clock size={12} className="mr-1" />
                    <span>{new Date(dataset.created).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <button className={`p-1 rounded-full ${
                dataset.favorites > 30 ? 'text-yellow-500' : 'text-gray-400 dark:text-gray-600'
              }`}>
                <Star size={18} fill={dataset.favorites > 30 ? 'currentColor' : 'none'} />
              </button>
            </div>
            
            <p className="mt-4 text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
              {dataset.description}
            </p>
            
            <div className="mt-4 flex flex-wrap gap-1">
              {dataset.tags.slice(0, 3).map((tag, index) => (
                <span 
                  key={index}
                  className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300"
                >
                  {tag}
                </span>
              ))}
              {dataset.tags.length > 3 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                  +{dataset.tags.length - 3}
                </span>
              )}
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center text-sm">
              <div className="flex items-center text-gray-500 dark:text-gray-400">
                <FileText size={14} className="mr-1" />
                <span>{dataset.rows} 행</span>
                <span className="mx-1">•</span>
                <span>{dataset.size}</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex items-center text-gray-500 dark:text-gray-400">
                  <Download size={14} className="mr-1" />
                  <span>{dataset.downloads}</span>
                </div>
                <div className="flex items-center text-gray-500 dark:text-gray-400">
                  <Star size={14} className="mr-1" />
                  <span>{dataset.favorites}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 flex justify-between items-center">
            <div className="flex items-center">
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                dataset.isVerified 
                  ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' 
                  : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
              }`}>
                {dataset.isVerified ? '검증됨' : '검증 대기중'}
              </span>
              <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                dataset.isPublic 
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' 
                  : 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
              }`}>
                {dataset.isPublic ? '공개' : '비공개'}
              </span>
            </div>
            <div className="flex space-x-2">
              <button className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                <Share size={16} />
              </button>
              <button className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                <Download size={16} />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
  
  // List view for datasets
  const renderDatasetsList = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-900">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              데이터셋
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              유형
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              크기
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              <button className="flex items-center" onClick={() => setSortBy(sortBy === 'newest' ? 'oldest' : 'newest')}>
                생성일
                {sortBy === 'newest' ? <ArrowDown size={14} className="ml-1" /> : 
                 sortBy === 'oldest' ? <ArrowUp size={14} className="ml-1" /> : null}
              </button>
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              <button className="flex items-center" onClick={() => setSortBy('downloads')}>
                다운로드
                {sortBy === 'downloads' && <ArrowDown size={14} className="ml-1" />}
              </button>
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              <button className="flex items-center" onClick={() => setSortBy('favorites')}>
                즐겨찾기
                {sortBy === 'favorites' && <ArrowDown size={14} className="ml-1" />}
              </button>
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              작업
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {sortedDatasets.map((dataset) => (
            <tr key={dataset.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
              <td className="px-6 py-4">
                <div className="flex items-start">
                  <div className="p-1 bg-blue-100 dark:bg-blue-900 rounded text-blue-600 dark:text-blue-300">
                    <Database size={16} />
                  </div>
                  <div className="ml-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{dataset.title}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{dataset.owner}</div>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {dataset.tags.slice(0, 2).map((tag, index) => (
                        <span 
                          key={index}
                          className="text-xs px-1.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300"
                        >
                          {tag}
                        </span>
                      ))}
                      {dataset.tags.length > 2 && (
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                          +{dataset.tags.length - 2}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="text-sm text-gray-900 dark:text-white">{dataset.type}</span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <div>
                  <div>{dataset.size}</div>
                  <div>{dataset.rows} 행</div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                {new Date(dataset.created).toLocaleDateString()}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <Download size={14} className="mr-1" />
                  <span>{dataset.downloads}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <Star size={14} className={dataset.favorites > 30 ? 'text-yellow-500 mr-1' : 'mr-1'} fill={dataset.favorites > 30 ? 'currentColor' : 'none'} />
                  <span>{dataset.favorites}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <div className="flex space-x-2">
                  <button className="p-1 text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                    <Download size={16} />
                  </button>
                  <button className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                    <Star size={16} fill={dataset.favorites > 30 ? 'currentColor' : 'none'} />
                  </button>
                  <button className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                    <Share size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  return (
    <div className="p-6 space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">배터리 데이터셋</h1>
        
        {/* Search bar */}
        <div className="relative flex-grow max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="데이터셋 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md leading-5 bg-white dark:bg-gray-800 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          />
        </div>
      </div>
      
      {/* Filters and view options */}
      <div className="flex flex-col md:flex-row md:justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {/* Tags filter */}
          <div className="relative">
            <button 
              onClick={() => toggleFilter('tags')}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none"
            >
              <Tag size={16} className="mr-2" />
              태그 필터
              {expandedFilter === 'tags' ? <ChevronUp size={16} className="ml-2" /> : <ChevronDown size={16} className="ml-2" />}
            </button>
            
            {expandedFilter === 'tags' && (
              <div className="absolute left-0 mt-2 w-56 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 z-10">
                <div className="p-2 divide-y divide-gray-200 dark:divide-gray-700">
                  <div className="py-2 px-2 text-sm text-gray-700 dark:text-gray-300 font-medium">태그 선택</div>
                  <div className="py-2 space-y-1 max-h-48 overflow-y-auto">
                    {filterOptions.tags.map((tag, index) => (
                      <div key={index} className="px-2 py-1 flex items-center">
                        <input
                          type="checkbox"
                          id={`tag-${index}`}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor={`tag-${index}`} className="ml-2 text-sm text-gray-900 dark:text-gray-100">
                          {tag}
                        </label>
                      </div>
                    ))}
                  </div>
                  <div className="py-2 px-2 flex justify-end">
                    <button className="px-3 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700">
                      적용
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Type filter */}
          <div className="relative">
            <button 
              onClick={() => toggleFilter('types')}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none"
            >
              <Database size={16} className="mr-2" />
              데이터 유형
              {expandedFilter === 'types' ? <ChevronUp size={16} className="ml-2" /> : <ChevronDown size={16} className="ml-2" />}
            </button>
            
            {expandedFilter === 'types' && (
              <div className="absolute left-0 mt-2 w-44 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 z-10">
                <div className="p-2 divide-y divide-gray-200 dark:divide-gray-700">
                  <div className="py-2 px-2 text-sm text-gray-700 dark:text-gray-300 font-medium">데이터 유형 선택</div>
                  <div className="py-2 space-y-1">
                    {filterOptions.types.map((type, index) => (
                      <div key={index} className="px-2 py-1 flex items-center">
                        <input
                          type="checkbox"
                          id={`type-${index}`}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor={`type-${index}`} className="ml-2 text-sm text-gray-900 dark:text-gray-100">
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                  <div className="py-2 px-2 flex justify-end">
                    <button className="px-3 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700">
                      적용
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* More filters button */}
          <button className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none">
            <Filter size={16} className="mr-2" />
            추가 필터
          </button>
        </div>
        
        {/* View toggle */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md ${
              viewMode === 'grid'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400'
                : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-gray-700'
            }`}
          >
            <Grid size={16} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-md ${
              viewMode === 'list'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400'
                : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-gray-700'
            }`}
          >
            <List size={16} />
          </button>
        </div>
      </div>
      
      {/* Result stats */}
      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          {sortedDatasets.length}개의 데이터셋 중 {Math.min(sortedDatasets.length, 6)}개 표시
        </p>
        <div className="flex items-center">
          <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">정렬:</span>
          <select 
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="block w-32 pl-3 pr-10 py-2 text-sm border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="newest">최신순</option>
            <option value="oldest">오래된순</option>
            <option value="downloads">다운로드순</option>
            <option value="favorites">즐겨찾기순</option>
          </select>
        </div>
      </div>
      
      {/* Datasets list or grid */}
      <div>
        {viewMode === 'grid' ? renderDatasetCards() : renderDatasetsList()}
      </div>
      
      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-700 dark:text-gray-300">
            <span className="font-medium">6</span>개의 항목 중 <span className="font-medium">1</span>-<span className="font-medium">6</span> 표시
          </p>
        </div>
        <div className="flex space-x-2">
          <button className="px-3 py-1 border border-gray-300 dark:border-gray-700 rounded-md text-sm text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50" disabled>
            이전
          </button>
          <button className="px-3 py-1 border border-gray-300 dark:border-gray-700 rounded-md text-sm text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50" disabled>
            다음
          </button>
        </div>
      </div>
    </div>
  );
};

export default Datasets;
import React, { useState } from 'react';
import { Search, Layers, Database, FileText, LayoutGrid, Star, Clock, Users, MessageSquare, Plus, Filter, SortDesc, Grid, List } from 'lucide-react';

const MyPage = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('canvases');
  
  // Sample data for canvases and favorites
  const canvasData = [
    { 
      id: 'c1', 
      title: '배터리 셀 성능 분석 캔버스', 
      created: '2025-03-02', 
      lastModified: '2025-03-08', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 3,
      tags: ['셀', '성능', '분석']
    },
    { 
      id: 'c2', 
      title: '충방전 사이클 예측 모델', 
      created: '2025-02-15', 
      lastModified: '2025-03-05', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 1,
      tags: ['충방전', '예측', '모델']
    },
    { 
      id: 'c3', 
      title: '전해질 성분 분석 파이프라인', 
      created: '2025-01-28', 
      lastModified: '2025-03-01', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 2,
      tags: ['전해질', '성분', '분석']
    },
    { 
      id: 'c4', 
      title: '배터리 수명 예측 캔버스', 
      created: '2025-02-20', 
      lastModified: '2025-02-28', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 4,
      tags: ['수명', '예측', '캔버스']
    },
    { 
      id: 'c5', 
      title: '배터리 발열 패턴 분석', 
      created: '2025-02-10', 
      lastModified: '2025-02-25', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 2,
      tags: ['발열', '패턴', '분석']
    },
    { 
      id: 'c6', 
      title: '리튬이온 배터리 데이터 전처리', 
      created: '2025-01-15', 
      lastModified: '2025-02-20', 
      thumbnail: '/api/placeholder/200/120', 
      collaborators: 1,
      tags: ['리튬이온', '전처리', '배터리']
    },
  ];
  
  const favoritesData = {
    datasets: [
      { id: 'd1', title: '배터리 셀 수명주기 데이터', type: 'dataset', favorited: '2025-03-01', size: '2.4GB', rows: '1.2M' },
      { id: 'd2', title: '전해질 성분 분석 데이터셋', type: 'dataset', favorited: '2025-02-25', size: '1.8GB', rows: '950K' },
      { id: 'd3', title: '충방전 사이클 테스트 데이터', type: 'dataset', favorited: '2025-02-20', size: '3.2GB', rows: '1.5M' },
    ],
    reports: [
      { id: 'r1', title: '배터리 열화 패턴 분석 보고서', type: 'report', favorited: '2025-03-05', author: '김연구원', pages: 42 },
      { id: 'r2', title: '배터리 안전성 평가 리포트', type: 'report', favorited: '2025-02-28', author: '박안전', pages: 36 },
    ],
    apps: [
      { id: 'a1', title: '배터리 이상 감지 앱', type: 'app', favorited: '2025-03-02', developer: '이개발', version: '1.2.0' },
      { id: 'a2', title: '충방전 예측 시뮬레이터', type: 'app', favorited: '2025-02-15', developer: '정시뮬', version: '2.1.3' },
    ]
  };
  
  // Filter canvases based on search query
  const filteredCanvases = canvasData.filter(canvas => 
    canvas.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    canvas.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  // Get all favorites in a flat array for display
  const allFavorites = [
    ...favoritesData.datasets.map(item => ({ ...item, category: 'dataset' })),
    ...favoritesData.reports.map(item => ({ ...item, category: 'report' })),
    ...favoritesData.apps.map(item => ({ ...item, category: 'app' }))
  ].filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Render grid view for canvases
  const renderCanvasesGrid = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Add new canvas card */}
      <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 flex flex-col items-center justify-center h-64 cursor-pointer hover:border-blue-500 dark:hover:border-blue-400 transition-colors">
        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full text-blue-600 dark:text-blue-300">
          <Plus size={24} />
        </div>
        <p className="mt-4 text-gray-700 dark:text-gray-300 text-center">
          새 캔버스 만들기
        </p>
      </div>
      
      {/* Canvas cards */}
      {filteredCanvases.map(canvas => (
        <div 
          key={canvas.id}
          className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="h-32 bg-gray-200 dark:bg-gray-700 relative">
            <img 
              src={canvas.thumbnail} 
              alt={canvas.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute top-2 right-2 flex space-x-1">
              <button className="p-1 rounded-full bg-white/80 dark:bg-black/50 text-yellow-500">
                <Star size={16} fill="currentColor" />
              </button>
            </div>
          </div>
          <div className="p-4">
            <h3 className="font-medium text-gray-900 dark:text-white mb-1 truncate">
              {canvas.title}
            </h3>
            <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400 mb-2">
              <div className="flex items-center">
                <Clock size={12} className="mr-1" />
                <span>{new Date(canvas.lastModified).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center">
                <Users size={12} className="mr-1" />
                <span>{canvas.collaborators}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1">
              {canvas.tags.map((tag, index) => (
                <span 
                  key={index}
                  className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
  
  // Render list view for canvases
  const renderCanvasesList = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-900">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              제목
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              태그
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              마지막 수정일
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              협업자
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              작업
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {filteredCanvases.map(canvas => (
            <tr key={canvas.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
              <td className="px-6 py-4">
                <div className="flex items-center">
                  <Layers size={16} className="text-blue-500 mr-2" />
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{canvas.title}</span>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-wrap gap-1">
                  {canvas.tags.map((tag, index) => (
                    <span 
                      key={index}
                      className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                {new Date(canvas.lastModified).toLocaleDateString()}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <Users size={14} className="mr-1" />
                  <span>{canvas.collaborators}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <button className="p-1 rounded text-yellow-500">
                  <Star size={16} fill="currentColor" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  // Render favorites
  const renderFavorites = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-900">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              제목
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              유형
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              즐겨찾기 추가일
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              상세 정보
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              작업
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {allFavorites.map(item => (
            <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
              <td className="px-6 py-4">
                <div className="flex items-center">
                  {item.category === 'dataset' && <Database size={16} className="text-green-500 mr-2" />}
                  {item.category === 'report' && <FileText size={16} className="text-indigo-500 mr-2" />}
                  {item.category === 'app' && <LayoutGrid size={16} className="text-purple-500 mr-2" />}
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{item.title}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`text-xs px-2 py-1 rounded-full
                  ${item.category === 'dataset' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 
                    item.category === 'report' ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300' : 
                    'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                  }`}
                >
                  {item.category === 'dataset' ? '데이터셋' : 
                   item.category === 'report' ? '리포트' : '앱'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                {new Date(item.favorited).toLocaleDateString()}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                {item.category === 'dataset' && (
                  <div className="flex items-center space-x-2">
                    <span>{item.size}</span>
                    <span>•</span>
                    <span>{item.rows} 행</span>
                  </div>
                )}
                {item.category === 'report' && (
                  <div className="flex items-center space-x-2">
                    <span>작성자: {item.author}</span>
                    <span>•</span>
                    <span>{item.pages} 페이지</span>
                  </div>
                )}
                {item.category === 'app' && (
                  <div className="flex items-center space-x-2">
                    <span>개발자: {item.developer}</span>
                    <span>•</span>
                    <span>v{item.version}</span>
                  </div>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                <button className="p-1 rounded text-yellow-500">
                  <Star size={16} fill="currentColor" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  return (
    <div className="p-6 space-y-6">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">마이 페이지</h1>
        
        {/* Search bar */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md leading-5 bg-white dark:bg-gray-800 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          />
        </div>
      </div>
      
      {/* Tab navigation */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('canvases')}
            className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'canvases'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <div className="flex items-center">
              <Layers size={16} className="mr-2" />
              캔버스
            </div>
          </button>
          <button
            onClick={() => setActiveTab('favorites')}
            className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'favorites'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <div className="flex items-center">
              <Star size={16} className="mr-2" />
              즐겨찾기
            </div>
          </button>
        </nav>
      </div>
      
      {/* Action bar */}
      {activeTab === 'canvases' && (
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <button className="px-3 py-2 flex items-center text-sm font-medium rounded-md bg-white dark:bg-gray-800 shadow-sm border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
              <SortDesc size={16} className="mr-2" />
              최신순
            </button>
            <button className="px-3 py-2 flex items-center text-sm font-medium rounded-md bg-white dark:bg-gray-800 shadow-sm border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
              <Filter size={16} className="mr-2" />
              필터
            </button>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md ${
                viewMode === 'grid'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400'
                  : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-gray-700'
              }`}
            >
              <Grid size={16} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md ${
                viewMode === 'list'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400'
                  : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-gray-700'
              }`}
            >
              <List size={16} />
            </button>
          </div>
        </div>
      )}
      
      {/* Content area */}
      <div className="mt-4">
        {activeTab === 'canvases' && viewMode === 'grid' && renderCanvasesGrid()}
        {activeTab === 'canvases' && viewMode === 'list' && renderCanvasesList()}
        {activeTab === 'favorites' && renderFavorites()}
      </div>
    </div>
  );
};

export default MyPage;
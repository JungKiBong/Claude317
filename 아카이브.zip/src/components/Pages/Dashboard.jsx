import React from 'react';
import { LineChart, Calendar, Clock, Database, FileText, Users, Activity, Layers, PieChart, BarChart } from 'lucide-react';

const Dashboard = () => {
  // Sample data for cards
  const quickAccessItems = [
    { title: '배터리 성능 분석 리포트', icon: <LineChart size={20} />, type: 'report', date: '2025-03-05' },
    { title: '배터리 수명 예측 모델', icon: <Activity size={20} />, type: 'model', date: '2025-02-28' },
    { title: '전해질 데이터셋', icon: <Database size={20} />, type: 'dataset', date: '2025-03-01' },
    { title: '셀 분석 캔버스', icon: <Layers size={20} />, type: 'canvas', date: '2025-03-08' },
  ];
  
  const recentReports = [
    { title: '배터리 열화 분석 보고서', views: 126, author: '김연구원', date: '2025-03-07' },
    { title: '충방전 패턴 분석', views: 98, author: '이분석가', date: '2025-03-02' },
    { title: 'BMS 데이터 해석 가이드', views: 205, author: '박엔지니어', date: '2025-02-25' },
  ];
  
  const upcomingEvents = [
    { title: '배터리 데이터 분석 워크숍', date: '2025-03-15 14:00', organizer: '연구개발팀' },
    { title: '신규 모델 검토 미팅', date: '2025-03-12 10:30', organizer: '데이터 사이언스팀' },
    { title: '월간 성과 보고', date: '2025-03-30 16:00', organizer: '경영지원팀' },
  ];
  
  return (
    <div className="p-6 space-y-6">
      {/* Welcome section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4 dark:text-white">BADA - Business Analytics & Data Analytics</h2>
        <p className="mb-4 text-gray-600 dark:text-gray-300">
          배터리 데이터 분석 및 비즈니스 인텔리전스를 위한 통합 플랫폼입니다.
        </p>
        <p className="mb-6 text-gray-600 dark:text-gray-300">
          좌측 메뉴를 통해 다양한 기능을 이용할 수 있습니다. BADA AI에 궁금한 점을 물어보세요!
        </p>
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            시작하기
          </button>
          <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            사용자 가이드
          </button>
        </div>
      </div>

      {/* Quick Access / My Items */}
      <div>
        <h2 className="text-lg font-medium mb-4 dark:text-white">
          빠른 접근
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickAccessItems.map((item, index) => (
            <div 
              key={index} 
              className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border-l-4 border-blue-500 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="flex items-start">
                <div className="p-2 bg-blue-50 dark:bg-blue-900 rounded-md text-blue-600 dark:text-blue-300">
                  {item.icon}
                </div>
                <div className="ml-3">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    {item.title}
                  </h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500 dark:text-gray-400">
                    <div className="flex items-center">
                      <FileText size={12} className="mr-1" />
                      <span>{item.type}</span>
                    </div>
                    <div className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600 mx-2"></div>
                    <div className="flex items-center">
                      <Clock size={12} className="mr-1" />
                      <span>{new Date(item.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Middle section with 2 columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Reports */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="font-medium text-gray-900 dark:text-white">최근 리포트</h2>
            <button className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
              모두 보기
            </button>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {recentReports.map((report, index) => (
              <div key={index} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                  {report.title}
                </h3>
                <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                  <div className="flex items-center">
                    <Users size={12} className="mr-1" />
                    <span>{report.views} 조회</span>
                  </div>
                  <div className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600 mx-2"></div>
                  <div className="flex items-center">
                    <span>작성자: {report.author}</span>
                  </div>
                  <div className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600 mx-2"></div>
                  <div className="flex items-center">
                    <Clock size={12} className="mr-1" />
                    <span>{new Date(report.date).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="font-medium text-gray-900 dark:text-white">예정된 이벤트</h2>
            <button className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
              모두 보기
            </button>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                  {event.title}
                </h3>
                <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                  <div className="flex items-center">
                    <Calendar size={12} className="mr-1" />
                    <span>{new Date(event.date).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center">
                    <Users size={12} className="mr-1" />
                    <span>주최: {event.organizer}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Analytics Overview */}
      <div>
        <h2 className="text-lg font-medium mb-4 dark:text-white">
          분석 개요
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Stat cards */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-green-50 dark:bg-green-900 rounded-md text-green-600 dark:text-green-300">
                <Database size={20} />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">총 데이터셋</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">124</p>
              </div>
            </div>
            <div className="mt-2">
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '70%' }}></div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">70% 공간 사용 중</p>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-blue-50 dark:bg-blue-900 rounded-md text-blue-600 dark:text-blue-300">
                <FileText size={20} />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">리포트</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">56</p>
              </div>
            </div>
            <div className="flex justify-between items-center mt-2 text-xs text-gray-500 dark:text-gray-400">
              <span>내부: 42</span>
              <span>외부: 14</span>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-purple-50 dark:bg-purple-900 rounded-md text-purple-600 dark:text-purple-300">
                <Layers size={20} />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">분석 캔버스</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">37</p>
              </div>
            </div>
            <div className="flex justify-between items-center mt-2 text-xs text-gray-500 dark:text-gray-400">
              <span className="text-green-600 dark:text-green-400">↗ 지난달 대비 12% 증가</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
          <div className="flex justify-between mb-4">
            <h3 className="font-medium text-gray-900 dark:text-white">배터리 분석 트렌드</h3>
            <div className="flex space-x-2">
              <button className="text-xs px-2 py-1 rounded bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                일간
              </button>
              <button className="text-xs px-2 py-1 rounded bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                주간
              </button>
              <button className="text-xs px-2 py-1 rounded bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                월간
              </button>
            </div>
          </div>
          <div className="aspect-video bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
            <div className="flex flex-col items-center text-gray-500 dark:text-gray-400">
              <LineChart size={48} />
              <p className="mt-2 text-sm">라인 차트로 배터리 성능 트렌드 표시</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
          <div className="flex justify-between mb-4">
            <h3 className="font-medium text-gray-900 dark:text-white">데이터 유형 분포</h3>
            <button className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
              자세히 보기
            </button>
          </div>
          <div className="aspect-video bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
            <div className="flex flex-col items-center text-gray-500 dark:text-gray-400">
              <PieChart size={48} />
              <p className="mt-2 text-sm">파이 차트로 데이터 타입 분포 표시</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
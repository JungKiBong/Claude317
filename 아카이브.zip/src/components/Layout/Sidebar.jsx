import React from 'react';
import { 
  MessageSquare, 
  User, 
  Database, 
  Layers, 
  LineChart, 
  Code, 
  Layout, 
  Share2, 
  Upload, 
  BookOpen, 
  MessageCircle, 
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Sun,
  Moon
} from 'lucide-react';

const Sidebar = ({ 
  isExpanded, 
  setIsExpanded, 
  isDarkMode,
  setIsDarkMode, 
  activePage, 
  onMenuClick 
}) => {
  // Define menu items with their tooltips
  const menuItems = [
    { id: 'lighthouse', name: 'LightHouse', icon: <MessageSquare size={20} />, tooltip: 'BADA AI 채팅' },
    { id: 'mypage', name: 'MyPage', icon: <User size={20} />, tooltip: '저장된 Canvas 및 즐겨찾기 항목들' },
    { id: 'pipeline-canvas', name: 'Pipeline Canvas', icon: <Layers size={20} />, tooltip: '데이터셋 정의/저장' },
    { id: 'datasets', name: 'DataSets', icon: <Database size={20} />, tooltip: '데이터셋 공유/검색' },
    { id: 'report', name: 'Report', icon: <LineChart size={20} />, tooltip: '등록된 내부/외부 Report 공유/검색', hasSubmenu: true },
    { id: 'apps', name: 'Apps', icon: <Layout size={20} />, tooltip: '등록된 내부/외부 WebApp 검색', hasSubmenu: true },
    { id: 'devcode', name: 'DevCode', icon: <Code size={20} />, tooltip: '주피터노트북 화면 및 코드 공유/검색' },
    { id: 'devapp', name: 'DevApp', icon: <Share2 size={20} />, tooltip: 'Superset 및 AppSmith 연계 개발' },
    { id: 'pubapp', name: 'PubApp', icon: <Upload size={20} />, tooltip: 'Report 및 App 배포 - CI/CD, MLOps 연동' },
    { id: 'board', name: 'Board', icon: <BookOpen size={20} />, tooltip: '공지사항, 지식공유, 커뮤니티, 사용자 가이드, 팀 소개' },
    { id: 'voc', name: 'VOC 등록', icon: <MessageCircle size={20} />, tooltip: '요청 사항 접수 및 처리 현황 확인' },
    { id: 'settings', name: '설정', icon: <Settings size={20} />, tooltip: '시스템 설정' },
  ];

  return (
    <div 
      className={`
        ${isExpanded ? 'w-56' : 'w-16'} 
        flex flex-col 
        transition-all duration-300 ease-in-out 
        ${isDarkMode ? 'bg-gray-800' : 'bg-blue-50'}
      `}
    >
      {/* Logo */}
      <div className="p-4 flex items-center justify-center">
        <div 
          className={`
            w-10 h-10 rounded-full 
            flex items-center justify-center 
            cursor-pointer 
            ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} 
            hover:shadow-lg 
            transition-all duration-300
          `}
          onClick={() => onMenuClick('lighthouse')}
        >
          <span className="text-white font-bold text-lg">B</span>
        </div>
        {isExpanded && (
          <span className={`ml-3 font-semibold ${isDarkMode ? 'text-white' : 'text-blue-800'}`}>
            BADA
          </span>
        )}
      </div>
      
      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto py-4">
        {menuItems.map((item) => (
          <div 
            key={item.id}
            className={`
              flex items-center py-2 px-4 cursor-pointer mb-1
              ${isExpanded ? 'justify-start' : 'justify-center'} 
              ${item.id === activePage || 
                (item.id === 'report' && activePage === 'report') || 
                (item.id === 'apps' && activePage === 'apps')
                ? (isDarkMode ? 'text-white' : 'text-blue-700') 
                : (isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-blue-700')
              }
              ${item.id === 'lighthouse' ? 'relative lighthouse-icon' : ''}
              group
            `}
            onClick={() => onMenuClick(item.id)}
            title={!isExpanded ? item.tooltip : ''}
          >
            {/* Special styling for Lighthouse icon */}
            {item.id === 'lighthouse' ? (
              <div className={`
                flex-shrink-0
                relative z-10
                transition-transform duration-300 ease-in-out
                transform group-hover:scale-110
                ${item.id === activePage ? 'text-white' : ''}
              `}>
                <div className={`
                  absolute inset-0 
                  rounded-full 
                  ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} 
                  w-7 h-7 -m-1
                  opacity-${item.id === activePage ? '100' : '80'}
                  group-hover:opacity-100
                  transition-all duration-300
                `}></div>
                <div className="relative z-10 p-1">{item.icon}</div>
              </div>
            ) : (
              <div className="flex-shrink-0 transition-transform duration-200 ease-in-out transform group-hover:scale-110">
                {item.icon}
              </div>
            )}
            
            {isExpanded && (
              <>
                <span className="ml-3">{item.name}</span>
                {item.hasSubmenu && (
                  <div className="ml-auto">
                    {(item.id === activePage) 
                      ? <ChevronDown size={16} /> 
                      : <ChevronRight size={16} />
                    }
                  </div>
                )}
              </>
            )}
            
            {/* Tooltip for collapsed sidebar */}
            {!isExpanded && (
              <div className="absolute left-16 scale-0 rounded bg-gray-800 p-2 text-xs text-white group-hover:scale-100 z-20 min-w-max">
                {item.tooltip}
                <div className="absolute top-1/2 -left-1 -translate-y-1/2 border-4 border-transparent border-r-gray-800"></div>
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Dark Mode Toggle */}
      <div className="p-4 flex items-center justify-center">
        <button 
          className={`p-2 rounded-md ${
            isDarkMode 
              ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600' 
              : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
          }`}
          onClick={() => setIsDarkMode(!isDarkMode)}
        >
          {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
        </button>
        {isExpanded && (
          <span className={`ml-3 text-sm ${isDarkMode ? 'text-gray-300' : 'text-blue-600'}`}>
            {isDarkMode ? '라이트 모드' : '다크 모드'}
          </span>
        )}
      </div>
      
      {/* Sidebar Toggle Button */}
      <div className="p-4">
        <button 
          className={`
            w-full p-2 rounded-md 
            flex items-center justify-center 
            ${isDarkMode 
              ? 'bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white' 
              : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
            }
          `}
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded 
            ? <ChevronLeft size={14} /> 
            : <ChevronRight size={14} />
          }
        </button>
      </div>
      
      {/* CSS for Lighthouse icon animation */}
      <style jsx>{`
        .lighthouse-icon:before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background: ${isDarkMode ? 'rgba(37, 99, 235, 0.3)' : 'rgba(59, 130, 246, 0.3)'};
          opacity: 0;
          transition: all 0.3s ease;
        }
        
        .lighthouse-icon:hover:before {
          opacity: 1;
          animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
          0% {
            transform: translate(-50%, -50%) scale(0.8);
            opacity: 0.7;
          }
          70% {
            transform: translate(-50%, -50%) scale(1.1);
            opacity: 0.2;
          }
          100% {
            transform: translate(-50%, -50%) scale(0.8);
            opacity: 0.7;
          }
        }
      `}</style>
    </div>
  );
};

export default Sidebar;
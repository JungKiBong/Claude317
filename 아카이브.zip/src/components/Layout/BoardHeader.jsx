import React from 'react';
import { Grid, List, Calendar, Filter, Plus } from 'lucide-react';

const BoardHeader = ({ isDarkMode }) => {
  return (
    <div className={`py-3 px-6 flex items-center justify-between border-b ${
      isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
    }`}>
      <div className="flex items-center">
        <button className={`px-4 py-2 font-medium mr-2 ${
          isDarkMode ? 'text-white border-b-2 border-blue-500' : 'text-blue-600 border-b-2 border-blue-500'
        }`}>
          <div className="flex items-center">
            <Grid size={16} className="mr-2" />
            보드 뷰
          </div>
        </button>
        
        <button className={`px-4 py-2 font-medium mr-2 ${
          isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'
        }`}>
          <div className="flex items-center">
            <List size={16} className="mr-2" />
            리스트 뷰
          </div>
        </button>
        
        <button className={`px-4 py-2 font-medium mr-2 ${
          isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'
        }`}>
          <div className="flex items-center">
            <Calendar size={16} className="mr-2" />
            캘린더 뷰
          </div>
        </button>
      </div>
      
      <div className="flex items-center">
        <button className={`px-4 py-2 rounded-md mr-2 flex items-center ${
          isDarkMode ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
        }`}>
          <Filter size={16} className="mr-2" />
          필터
        </button>
        
        <button className={`px-4 py-1.5 rounded-md bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors`}>
          <div className="flex items-center">
            <Plus size={16} className="mr-2" />
            새 항목 생성
          </div>
        </button>
      </div>
    </div>
  );
};

export default BoardHeader;
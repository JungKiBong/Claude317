import React from 'react';
import {
  Search,
  X,
  ChevronDown,
  ChevronRight,
  Filter,
  Plus,
  Star
} from 'lucide-react';

const SubSidebar = ({ title, type, onClose, isDarkMode }) => {
  // Define submenu items based on type
  const getSubmenuItems = () => {
    if (type === 'report') {
      return [
        {
          title: '내부 리포트',
          expanded: true,
          items: [
            { id: 'r1', name: '배터리 셀 성능 분석 리포트', favorited: true },
            { id: 'r2', name: '배터리 수명 예측 리포트', favorited: false },
            { id: 'r3', name: '배터리 소재 분석 리포트', favorited: true },
            { id: 'r4', name: '배터리 품질 관리 리포트', favorited: false },
          ]
        },
        {
          title: '외부 리포트',
          expanded: false,
          items: [
            { id: 'r5', name: '전기차 배터리 시장 동향', favorited: false },
            { id: 'r6', name: '글로벌 배터리 제조사 분석', favorited: true },
          ]
        },
        {
          title: '대시보드',
          expanded: false,
          items: [
            { id: 'r7', name: '배터리 생산 현황 대시보드', favorited: false },
            { id: 'r8', name: '배터리 품질 모니터링', favorited: false },
          ]
        }
      ];
    } else if (type === 'apps') {
      return [
        {
          title: '내부 앱',
          expanded: true,
          items: [
            { id: 'a1', name: '배터리 데이터 탐색기', favorited: true },
            { id: 'a2', name: '배터리 이상 감지 앱', favorited: false },
            { id: 'a3', name: '배터리 수명 예측 모델', favorited: true },
          ]
        },
        {
          title: '외부 앱',
          expanded: false,
          items: [
            { id: 'a4', name: '배터리 시뮬레이션 툴', favorited: false },
            { id: 'a5', name: '전기차 충전 예측 앱', favorited: false },
          ]
        }
      ];
    }
    return [];
  };

  const handleItemClick = (id) => {
    console.log(`Clicked item: ${id}`);
  };

  const toggleFavorite = (e, id) => {
    e.stopPropagation();
    console.log(`Toggled favorite for: ${id}`);
  };

  return (
    <div className={`w-72 flex flex-col border-r ${
      isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
    }`}>
      <div className="p-4 border-b flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
            {title}
          </h2>
          <button 
            className={`p-1 rounded-full ${
              isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
            }`}
            onClick={onClose}
          >
            <X size={16} />
          </button>
        </div>
        
        {/* Search field */}
        <div className={`flex items-center p-2 rounded-md ${
          isDarkMode ? 'bg-gray-700' : 'bg-gray-100'
        }`}>
          <Search className={`h-4 w-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'} mr-2`} />
          <input 
            type="text" 
            placeholder={`${type === 'report' ? '리포트' : '앱'} 검색...`}
            className={`bg-transparent border-none outline-none text-sm flex-1 ${
              isDarkMode ? 'text-white placeholder-gray-500' : 'text-gray-800 placeholder-gray-400'
            }`}
          />
        </div>
      </div>
      
      {/* Tree menu */}
      <div className="flex-1 overflow-y-auto p-4">
        {getSubmenuItems().map((category, index) => (
          <div key={index} className="mb-4">
            <div className="flex items-center py-1.5 text-sm rounded-lg cursor-pointer">
              {category.expanded ? 
                <ChevronDown size={14} className="mr-2" /> : 
                <ChevronRight size={14} className="mr-2" />
              }
              <span className={`font-medium ${isDarkMode ? 'text-gray-200' : 'text-gray-700'}`}>
                {category.title}
              </span>
            </div>
            
            {category.expanded && (
              <div className="ml-6 mt-1">
                {category.items.map((item) => (
                  <div 
                    key={item.id} 
                    className={`py-2 text-sm flex items-center justify-between rounded-md px-2 cursor-pointer
                      ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}
                    `}
                    onClick={() => handleItemClick(item.id)}
                  >
                    <span className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                      {item.name}
                    </span>
                    <button 
                      className={`p-1 rounded-full transition-colors
                        ${item.favorited 
                          ? (isDarkMode ? 'text-yellow-400' : 'text-yellow-500') 
                          : (isDarkMode ? 'text-gray-600 hover:text-gray-400' : 'text-gray-400 hover:text-gray-600')
                        }
                      `}
                      onClick={(e) => toggleFavorite(e, item.id)}
                    >
                      <Star size={14} fill={item.favorited ? 'currentColor' : 'none'} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Action buttons */}
      <div className="p-4 border-t flex justify-between">
        <button className={`px-3 py-2 rounded-md text-sm ${
          isDarkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`}>
          <div className="flex items-center">
            <Plus size={14} className="mr-2" />
            <span>새 {type === 'report' ? '리포트' : '앱'}</span>
          </div>
        </button>
        
        <button className={`px-3 py-2 rounded-md text-sm ${
          isDarkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`}>
          <div className="flex items-center">
            <Filter size={14} className="mr-2" />
            <span>필터</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default SubSidebar;
import React from 'react';
import { Search, Bell, HelpCircle } from 'lucide-react';

const Header = ({ isDarkMode, title }) => {
  const currentDate = new Date();
  const formattedDate = new Intl.DateTimeFormat('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(currentDate);

  return (
    <div className={`py-3 px-6 flex items-center justify-between border-b ${
      isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
    }`}>
      <div className="flex items-center">
        <h1 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
          {title}
        </h1>
        <button 
          className={`ml-3 w-7 h-7 rounded-full 
            ${isDarkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white' : 'bg-gray-200 text-gray-600 hover:bg-gray-300 hover:text-gray-800'} 
            flex items-center justify-center
          `}
          title="도움말"
        >
          <HelpCircle size={16} />
        </button>
      </div>
      
      <div className="flex items-center">
        <div className="mr-4">
          <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            안녕하세요, 데이터 분석가님
          </span>
          <span className="ml-1">👋</span>
        </div>
        
        <div className="flex items-center">
          <button 
            className={`p-2 rounded-md transition-colors ${
              isDarkMode ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
            }`}
            title="검색"
          >
            <Search size={18} />
          </button>
          
          <button 
            className={`p-2 rounded-md transition-colors relative ${
              isDarkMode ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
            }`}
            title="알림"
          >
            <Bell size={18} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          
          <div className="ml-4 px-3 py-1 flex items-center">
            <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'} mr-1`}>
              {formattedDate}
            </span>
            <div className={`w-8 h-8 rounded-full ml-4 flex items-center justify-center ${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
            }`}>
              <span className={`font-medium text-sm ${isDarkMode ? 'text-gray-200' : 'text-gray-600'}`}>
                DA
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
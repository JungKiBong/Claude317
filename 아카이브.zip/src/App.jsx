import React, { useState, useEffect } from 'react';
import Sidebar from './components/Layout/Sidebar';
import SubSidebar from './components/Layout/SubSidebar';
import Header from './components/Layout/Header';
import BoardHeader from './components/Layout/BoardHeader';
import ChatInterface from './components/Chat/ChatInterface';
import Dashboard from './components/Pages/Dashboard';
import MyPage from './components/Pages/MyPage';
import Datasets from './components/Pages/Datasets';
import { 
  PipelineCanvas, 
  Reports, 
  Apps, 
  DevCode, 
  DevApp, 
  PubApp, 
  Board, 
  VOC, 
  SettingsPage 
} from './components/Pages/PlaceholderPages';

const App = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [activePage, setActivePage] = useState('dashboard');
  const [isSubSidebarOpen, setIsSubSidebarOpen] = useState(false);
  const [isAppsSidebarOpen, setIsAppsSidebarOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  
  // Check for system dark mode preference
  useEffect(() => {
    const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    setIsDarkMode(darkModeMediaQuery.matches);
    
    const handleChange = (e) => {
      setIsDarkMode(e.matches);
    };
    
    darkModeMediaQuery.addEventListener('change', handleChange);
    
    return () => {
      darkModeMediaQuery.removeEventListener('change', handleChange);
    };
  }, []);
  
  // Handle menu item clicks
  const handleMenuClick = (menuId) => {
    if (menuId === 'lighthouse') {
      setChatOpen(true);
    } else if (menuId === 'report') {
      setIsSubSidebarOpen(!isSubSidebarOpen);
      if (isAppsSidebarOpen) setIsAppsSidebarOpen(false);
    } else if (menuId === 'apps') {
      setIsAppsSidebarOpen(!isAppsSidebarOpen);
      if (isSubSidebarOpen) setIsSubSidebarOpen(false);
    } else {
      setActivePage(menuId);
      setChatOpen(false);
    }
  };
  
  // Render page content based on active page
  const renderPageContent = () => {
    if (chatOpen) return <ChatInterface onClose={() => setChatOpen(false)} />;
    
    switch (activePage) {
      case 'mypage': return <MyPage />;
      case 'pipeline-canvas': return <PipelineCanvas />;
      case 'datasets': return <Datasets />;
      case 'report': return <Reports />;
      case 'apps': return <Apps />;
      case 'devcode': return <DevCode />;
      case 'devapp': return <DevApp />;
      case 'pubapp': return <PubApp />;
      case 'board': return <Board />;
      case 'voc': return <VOC />;
      case 'settings': return <SettingsPage />;
      default: return <Dashboard />;
    }
  };
  
  return (
    <div className={`flex h-screen ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100'}`}>
      {/* Main Sidebar */}
      <Sidebar 
        isExpanded={sidebarExpanded}
        setIsExpanded={setSidebarExpanded}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        activePage={activePage}
        onMenuClick={handleMenuClick}
      />
      
      {/* Report SubSidebar */}
      {isSubSidebarOpen && (
        <SubSidebar 
          title="Report 카테고리" 
          type="report"
          onClose={() => setIsSubSidebarOpen(false)}
          isDarkMode={isDarkMode}
        />
      )}
      
      {/* Apps SubSidebar */}
      {isAppsSidebarOpen && (
        <SubSidebar 
          title="Apps 카테고리" 
          type="apps"
          onClose={() => setIsAppsSidebarOpen(false)}
          isDarkMode={isDarkMode}
        />
      )}
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          isDarkMode={isDarkMode} 
          title={chatOpen ? "BADA AI 채팅" : "BADA 대시보드"}
        />
        
        {!chatOpen && <BoardHeader isDarkMode={isDarkMode} />}
        
        {/* Page Content */}
        <div className="flex-1 overflow-auto">
          {renderPageContent()}
        </div>
      </div>
      
      {/* Dark Mode Toggle (Floating) */}
      <div className="fixed bottom-6 right-6 z-10">
        <button 
          className={`p-3 rounded-full shadow-lg ${
            isDarkMode 
              ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600' 
              : 'bg-white text-blue-600 hover:bg-blue-50'
          }`}
          onClick={() => setIsDarkMode(!isDarkMode)}
          aria-label={isDarkMode ? "라이트 모드로 전환" : "다크 모드로 전환"}
        >
          {isDarkMode ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
          )}
        </button>
      </div>
    </div>
  );
};

export default App;